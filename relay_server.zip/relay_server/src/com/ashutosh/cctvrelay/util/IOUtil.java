package com.ashutosh.cctvrelay.util;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public class IOUtil {
	public static String readAll(String fileName)
	{
		StringBuilder sb = new StringBuilder();
		
		FileInputStream fis=null;
		InputStreamReader isr = null;
		BufferedReader br = null;
		String line="";
		
		try {
			fis = new FileInputStream(fileName);
			isr = new InputStreamReader(fis, StandardCharsets.UTF_8);
			br = new BufferedReader(isr);
			while(true)
			{
				line = br.readLine();
				if(line==null)break;
				
				if(line.trim().length()>0)
				{
					sb.append(line);
				}
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally{
			if(br!=null)
			{
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			
			if(isr!=null)
			{
				try {
					isr.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}				
			
			if(fis!=null)
			{
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
		return sb.toString();
	}
	
	public static String readAll(InputStream is)
	{
		StringBuilder sb = new StringBuilder();
		
		InputStreamReader isr = null;
		BufferedReader br = null;
		String line="";
		
		try {
			isr = new InputStreamReader(is);
			br = new BufferedReader(isr);
			while(true)
			{
				line = br.readLine();
				if(line==null)break;
				
				if(line.trim().length()>0)
				{
					sb.append(line);
				}
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally{
			if(br!=null)
			{
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			
			if(isr!=null)
			{
				try {
					isr.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}				
		}
		
		return sb.toString();
	}	
}
