package com.ashutosh.cctvrelay.util;

import com.google.gson.Gson;
import com.google.gson.internal.LinkedTreeMap;

public class GsonUtil {
	private static Gson gson = new Gson();
	
	public static LinkedTreeMap getObjectFromJson(String json)
	{
		return gson.fromJson(json, LinkedTreeMap.class);
	}
}
