package com.ashutosh.cctvrelay.server;

import java.io.IOException;
import java.net.InetSocketAddress;

import com.ashutosh.cctvrelay.server.MjpegStreamer.rootHandler;
import com.ashutosh.cctvrelay.server.MjpegStreamer.streamHandler;
import com.sun.net.httpserver.HttpServer;

//http://tutorials.jenkov.com/java-multithreaded-servers/thread-pooled-server.html
public class Main
{
	public static void main(String[] args) 
	{
		ProducerPooledServer server1 = new ProducerPooledServer(9000);
		new Thread(server1).start();
		
	      try {
	    	  HttpServer server = HttpServer.create(new InetSocketAddress(9001),0);
			  server.createContext("/", new rootHandler());
			  server.createContext("/stream", new streamHandler());
			  server.setExecutor(null);
			  server.start();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
