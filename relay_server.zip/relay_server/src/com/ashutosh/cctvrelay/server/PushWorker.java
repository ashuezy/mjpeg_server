package com.ashutosh.cctvrelay.server;

import java.io.InputStream;
import java.io.IOException;
import java.net.Socket;

import com.google.gson.internal.LinkedTreeMap;
import com.ashutosh.cctvrelay.util.GsonUtil;
import com.ashutosh.cctvrelay.util.IOUtil;

public class PushWorker implements Runnable
{
    protected Socket clientSocket = null;
    protected String serverText   = null;

    public PushWorker(Socket clientSocket, String serverText) {
        this.clientSocket = clientSocket;
        this.serverText   = serverText;
    }

    public void run()
    {
        try {
            InputStream input  = clientSocket.getInputStream();
            int size = input.available();
            
            if(size>0)
            {
	            String json = IOUtil.readAll(input); 
	            if(json.length()>0)
	            {
		            try
		            {
		            	LinkedTreeMap map = GsonUtil.getObjectFromJson(json);
		            	
	            		String cameraId = (String)map.get("cameraId");
	            		String base64 = (String)map.get("frame");
	            	
	            		Pipeline.push(cameraId, base64);
		            }
		            catch(Exception e)
		            {
		            	e.printStackTrace();
		            	System.out.println("Exception::"+json);
		            }
	            }
            }
            
            input.close();
        } catch (IOException e) {
            //report exception somewhere.
            e.printStackTrace();
        }
    }
}